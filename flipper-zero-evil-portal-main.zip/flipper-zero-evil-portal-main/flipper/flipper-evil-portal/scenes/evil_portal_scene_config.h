ADD_SCENE(evil_portal, start, Start)
ADD_SCENE(evil_portal, console_output, ConsoleOutput)
