#pragma once

#ifdef __cplusplus
extern "C" {
#endif

typedef struct Evil_PortalApp Evil_PortalApp;

#ifdef __cplusplus
}
#endif
