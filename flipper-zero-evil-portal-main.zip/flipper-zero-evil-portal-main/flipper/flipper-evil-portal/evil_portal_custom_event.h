#pragma once

typedef enum {
  Evil_PortalEventRefreshConsoleOutput = 0,
  Evil_PortalEventStartConsole,
  Evil_PortalEventStartKeyboard,
  Evil_PortalEventStartPortal,
} Evil_PortalCustomEvent;
